from random import randint
import requests
import discord
from json import loads
from asyncio import sleep


#Variables Bot :
TOKEN = "MTE5MDYwODI3NzU5MjA4ODU3Ng.GeRzSO.m6YFiTSb47YRFo5n80YY_UeljSNVDBuOoY5B9s"

intents = discord.Intents.default()
intents.presences = True
intents.members = True
intents.message_content = True
client = discord.Client(intents=intents)

channel_id = 1167789020575711262
channel_name = "suggestions-v2-diplomacy"

#Variables programme :
stat_limite = 15
arsenaux = ["Berlin", "Munich", "Kiel", "Londres", "Édimbourg", "Liverpool", "Vienne", "Budapest", "Trieste", "Paris", "Marseille", "Brest", "Rome", "Venise", "Naples", "Moscou", "Sébastopol", "Varsovie", "St Pétersbourg", "Ankara", "Constantinople", "Smyrne"]
regions = ["Kiel", "Munich", "Prusse", "Ruhr", "Silésie","Clyde","Edimbourg","Liverpool","Londres","Pays de Galles","Yorkshire","Bohème", "Budapest", "Galicie", "Trieste", "Tyrol", "Vienne", "Brest", "Bourgogne", "Gascogne ", "Marseille", "Paris", "Picardie", "Apulie", "Naples", "Piémont","Rome","Toscane","Venise","Livonie","Moscou","Sébastopol","Saint-Pétersbourg","Ukraine","Varsovie","Ankara","Arménie","Constantinople","Smyrne","Syrie","Afrique du Nord","Albanie","Belgique","Bulgarie","Danemark","Espagne","Finlande","Grèce","Norvège","Portugal","Roumanie","Serbie","Suède","Tunisie","Atlantique moyen","Atlantique Nord","Baie de Helgoland","Golfe de Botnie","Golfe du Lion","Manche","Méditerranée occidentale","Méditerranée orientale","Mer Adriatique","Mer Baltique","Mer de Barents","Mer de Norvège","Mer du Nord","Mer d'Irlande","Mer Egée","Mer Ionienne","Mer Noire","Mer Tyrrhénienne","Skaggerak"]
pays = ["Italie", "France", "Russie", "Turquie", "Autriche", "Allemagne", "Angleterre"]
regions_terrestre = ["Kiel", "Munich", "Prusse", "Ruhr", "Silésie","Clyde","Edimbourg","Liverpool","Londres","Pays de Galles","Yorkshire","Bohème", "Budapest", "Galicie", "Trieste", "Tyrol", "Vienne", "Brest", "Bourgogne", "Gascogne ", "Marseille", "Paris", "Picardie", "Apulie", "Naples", "Piémont","Rome","Toscane","Venise","Livonie","Moscou","Sébastopol","Saint-Pétersbourg","Ukraine","Varsovie","Ankara","Arménie","Constantinople","Smyrne","Syrie","Afrique du Nord","Albanie","Belgique","Bulgarie","Danemark","Espagne","Finlande","Grèce","Norvège","Portugal","Roumanie","Serbie","Suède","Tunisie"]
mers = ["Atlantique moyen","Atlantique Nord","Baie de Helgoland","Golfe de Botnie","Golfe du Lion","Manche","Méditerranée occidentale","Méditerranée orientale","Mer Adriatique","Mer Baltique","Mer de Barents","Mer de Norvège","Mer du Nord","Mer d'Irlande","Mer Egée","Mer Ionienne","Mer Noire","Mer Tyrrhénienne","Skaggerak"]
an = 1939
campagnes = ["Campagne d'été ", "Campagne d'automne "]
n_campagne = 0

@client.event
async def on_ready():
    print("connected")
    
@client.event
async def on_message(message):
    print(message.content)
    
    if message.content == "events":
            print(message.channel)

            def formatage(path_file): 
                obfi = open(path_file, "r")
                while 1:
                    line = obfi.readline()
                    if line == '':
                        break
                    line = line.replace('\n', '')
                    line = '"' + line + '"' + ","
                    print(line, end='')
                    
            def Pb():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions[randint(0, len(regions)-1)]
                    pbs = ["une epidemie ", "un volcan ", "une famine ", "un accident ", "un seisme "]
                    pb = pbs[randint(0, len(pbs)-1)]

                    retour = "Malus de defense : " + str(region_cible) + " subit " + str(pb) + "soit un malus de 0.5 en defense. " + "\n"
                    return retour
                    
            def isolement():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions[randint(0, len(regions)-1)]
                    

                    retour = "Isolement : " + str(region_cible) + " subit une tempete de neige ou de sable et rencontre donc un isolement complet du reste du monde, les troupes ne peuvent ni entrer ni sortir. " + "\n"
                    return retour
                
            def Rebellion():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
                    
                    retour = "Guerre Civile : " + str(region_cible) + " subit une guerre civile, la region s'autonomise et compte bien se defendre. Elle devient neutre et une armée blanche apparait. " + "\n"                           
                    return retour
                
            def MerGelée():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = mers[randint(0, len(mers)-1)]
                    
                    retour = "Mer Gelée : " + str(region_cible) + " est traversée par une vague de froid; la mer a gelé. Les unités terrestres pourront la traverser pour la prochaine campagne contrairement aux flottes. Si une flotte est prise par la glace, elle empeche la circulation dans cette mer et ne peut pas bouger lors de cette campagne. " + "\n"
                    return retour
                    
            def SoutienPopulaire():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
                    
                    retour = " Soutien Populaire : L'armée de " + str(region_cible) + " profite du soutien popupaire, qui lui procure 0.5 de bonus en attaque et lors de cette campagne. " + "\n"       
                    return retour
                    
            def Blitzkrieg():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
                    
                    retour = "Blitzkrieg : un reservoir de super carburant est decouvert en " + str(region_cible) + ". L'unité presente sur cette case peut se deplacer 2 fois pour la prochaine campagne. " + "\n"                       
                    return retour
                    
            def enlisement():
                activate =  randint(1,100)
                if activate <= stat_limite:
                    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
                    
                    retour = "Enlisement : L'unité terreste de " + str(region_cible) + " n'a pas été assez prudente et s'est enlisée dans un marais. Elle ne pourra bouger lors de la campagne suivante que si une unité alliée se trouve sur une case adjacente. " + "\n"
                    return retour
                
            def date():
                année = int(an + n_campagne/2)
                if n_campagne - 2*int(n_campagne/2) == 0:
                    campagne = campagnes[0]
                else:
                    campagne = campagnes[1]
                retour = str(campagne) + str(année) + ": " + "\n"
                print(retour)
                return retour
                
            def LaTotale():
                global n_campagne
                retour = ''
                liste_actions = [Pb(), isolement(), Rebellion(), MerGelée(), SoutienPopulaire(), Blitzkrieg(), enlisement()]
                for i  in liste_actions:
                    print(type(i))
                    if i != None:
                        retour = retour + " --> " + str(i)
                
                n_campagne += 1 

                retour.replace('None', '')
                if retour =='':
                    retour = "rien a signaler pour cette campagne."
                return retour
                
            def ToDiscord():

                message = "Jour/Nuit"
                channel_id = "1167789020575711262"
                token = "MTE5MDYwODI3NzU5MjA4ODU3Ng.GeRzSO.m6YFiTSb47YRFo5n80YY_UeljSNVDBuOoY5B9s"
                payload = {"content" : message}
                header = {"authorization":token}
                requests.post("https://discord.com/api/v9/channels/"+channel_id+"/messages",data=payload,headers=header)

            #for i in range(10):
            #    LaTotale()
            msg = str(date()) + str(LaTotale())
            await message.channel.send(msg)
            await message.delete()
            
    if message.content == "eventss":
        await message.channel.send("La fin du monde a commmencée... Inutile de continuer la partie. ;(")
        await message.delete()
        
client.run(TOKEN)
