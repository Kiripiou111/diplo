from random import randint
import requests
import discord
from json import loads
from asyncio import sleep


#Variables Bot :
TOKEN = "MTE5MDYwODI3NzU5MjA4ODU3Ng.GeRzSO.m6YFiTSb47YRFo5n80YY_UeljSNVDBuOoY5B9s"

intents = discord.Intents.default()
intents.presences = True
intents.members = True
intents.message_content = True
client = discord.Client(intents=intents)

channel_id = 1167789020575711262
channel_name = "suggestions-v2-diplomacy"

admin_liste = [922077625583804426, 567122368686981133, 697918875500544091, 705115312986521681, 1192918958144241706]

#Variables programme :
stat_limite = 15
arsenaux = ["BAT", "San", "South Pole", "Showa", "Mawson","Vostok", "Casey", "New Zealand", "Queensland", "Western Australia", "Indonesia", "Thailand", "Gua", "Lanzhou", "Ban", "Bei", "Sha", "Japan", "Vla", "Yakustk", "Krasnoyark", "Yamalia", "Afg", "Arm", "Mos", "Var", "StP", "Sca", "Germany", "France", "England", "Ukr", "Ita", "Turkey", "Syria", "Iraq", "Saudi Arabia", "Suez", "Sudan", "Lybia", "Morocco", "Mali", "Guinea", "Accra", "Cameron", "Chad", "Con", "Zaire", "Nam", "Cape", "Zim", "Moz","Tan", "Nai", "Uga", "Eth", "Mumbai", "Cal", "Del", "Chile", "SCr", "Buenos Aires", "Uruguay", "Bolivia", "Rio de Janeiro", "Sal", "Recife", "Ama", "Brasilia", "Ecuador", "Bogota", "Venezuala", "Mexico", "Florida", "Deep South", "Union", "Midwest", "Lakes", "Clf", "Pac", "BriCol", "Man", "Quebec", "Nwf", "NW territory", "Alaska", "Godthab", "Galapagos"]
regions = ["North Pacific Ocean", "Bering Sea", "Arctic Sea", "Central Pacific Ocean", "Pacific Islands", "RIS", "BellingHausen Sea", "South Pacific Ocean", "East Pacific Ocean", "Gulf of Alsaka", "Scotia Sea", "West Atlantic Ocean", "Central Atlantic Ocean", "Caribbean Sea", "Gulf of Mexico", "Sargasso Sea", "Labrador Sea", "Hudson Bay", "Beaufort Sea", "Barent Sea", "North Atlantic Sea", " Gulf of guinea", "East Atlantic Ocean", "Riiser Larsen Sea", "Med", "Nth", "Bas", "Bla", "Red Sea", "Cosmonauts Sea", "McH", "West Indian Ocean", "Arabian Sea", "North Indian Ocean", "South Indian Ocean", "East Indian Ocean", "Mawson Sea", "D'urville Sea", "Caspian Sea", "Amundsen Sea", "Tasman Sea", "Java Sea", "South China Sea", "Bay of Bengal", "Phillipine Sea", "East China Sea", "Sea of Japan", "Sea of Okhostk", "East Siberian Sea", "Arctic Ocean", "Alaska", "Yukon", "NW territory", "Quebec", "BriCol", "Alb", "Sas", "Man", "Ont", "Nwf", "Pac", "Midwest", "Gt lakes", "Union", "CLF", "Texas", "Deep South", "Florida", "Monterrey", "Mexico", "Panama", "Bogota", "Vel", "Lima", "Peru", "Ama", "Brasila", "Guyane", "Recife", "Sal", "Rio de Janeiro", " sao Paolo", "Bolivia", "Chile", " Men", "Uruguay", "Buenos Aires", "SCr", "Ecuador", "Thule", "Godthab", "Galapagos", "Hawai", "Mary Byrd Land", "Ape", "BAt", "san", "Nov", "Showa", "NOrwergian dependancy", "South Pole", "Vostok", "Mawson", "Casey", "DMv", "Len", "Ross Ice Shelf", "Western Australia", "South Australia", "Northern Territory", "New South Wales", "Queens Land", "Victoria", "New Zealand", "Indonesia", "Philippines", "Thailand", "Vietnam", "Gua", "Sha", "Bur", "Ban", "Lanzhou", "Bei", "Hei", "Vla", "Korea", "Japan", "Kamtchakta", "Yakustsk", "Inner Mon", "Cal", "Mumbia", "Pak", "Afg", "West china", "Tibet", "Qin", "Mongolia", "Irkustk", "Omsk", "Kranoyarsk", "Kyr", "Iran", "Kazakhstan", "Yamalia", "Mos", "StP", "Arm", "Turkey", "Ukr", "Balcans", "Austria-Hungaria", "Poland", "Germany", "France", "Spain", "England", "Sca", "Bst", "Italia", "Varsovie", "Cape", "Bot", "Nam", "Zim", "Moz", "Ang", "Madagascar", "Tan", "Zaire", "Con", "Uga", "Nai", "Som", "Eth", "S Sud", "CAR", "Nga", "Accra", "Gui", "Mau", "Mor", "Algeria", "Mali", "Niger", "Chad", "Sudan", "Lybia", "Suez", "Cam", "Saudi Arabia", "Syrie", "Iraq"]
pays = ["Etats-Unis (Ouest)", "Inde", "Cartel du Sud Argentine", "Afrique du Sud", "Russie (Est)", "Etats-Unis (Est)", "France", "Australie", "Canada", "Russie (Ouest)", "Empire Ottoman", "Antarctique", " Vénezuela", "Brésil", "Congo", "Mali", "Egypte", "Chine"]
regions_terrestre = ["Alaska", "Yukon", "NW territory", "Quebec", "BriCol", "Alb", "Sas", "Man", "Ont", "Nwf", "Pac", "Midwest", "Gt lakes", "Union", "CLF", "Texas", "Deep South", "Florida", "Monterrey", "Mexico", "Panama", "Bogota", "Vel", "Lima", "Peru", "Ama", "Brasila", "Guyane", "Recife", "Sal", "Rio de Janeiro", " sao Paolo", "Bolivia", "Chile", " Men", "Uruguay", "Buenos Aires", "SCr", "Ecuador", "Thule", "Godthab", "Galapagos", "Hawai", "Mary Byrd Land", "Ape", "BAt", "san", "Nov", "Showa", "NOrwergian dependancy", "South Pole", "Vostok", "Mawson", "Casey", "DMv", "Len", "Ross Ice Shelf", "Western Australia", "South Australia", "Northern Territory", "New South Wales", "Queens Land", "Victoria", "New Zealand", "Indonesia", "Philippines", "Thailand", "Vietnam", "Gua", "Sha", "Bur", "Ban", "Lanzhou", "Bei", "Hei", "Vla", "Korea", "Japan", "Kamtchakta", "Yakustsk", "Inner Mon", "Cal", "Mumbia", "Pak", "Afg", "West china", "Tibet", "Qin", "Mongolia", "Irkustk", "Omsk", "Kranoyarsk", "Kyr", "Iran", "Kazakhstan", "Yamalia", "Mos", "StP", "Arm", "Turkey", "Ukr", "Balcans", "Austria-Hungaria", "Poland", "Germany", "France", "Spain", "England", "Sca", "Bst", "Italia", "Varsovie", "Cape", "Bot", "Nam", "Zim", "Moz", "Ang", "Madagascar", "Tan", "Zaire", "Con", "Uga", "Nai", "Som", "Eth", "S Sud", "CAR", "Nga", "Accra", "Gui", "Mau", "Mor", "Algeria", "Mali", "Niger", "Chad", "Sudan", "Lybia", "Suez", "Cam", "Saudi Arabia", "Syrie", "Iraq"]
mers = ["North Pacific Ocean", "Bering Sea", "Arctic Sea", "Central Pacific Ocean", "Pacific Islands", "RIS", "BellingHausen Sea", "South Pacific Ocean", "East Pacific Ocean", "Gulf of Alsaka", "Scotia Sea", "West Atlantic Ocean", "Central Atlantic Ocean", "Caribbean Sea", "Gulf of Mexico", "Sargasso Sea", "Labrador Sea", "Hudson Bay", "Beaufort Sea", "Barent Sea", "North Atlantic Sea", " Gulf of guinea", "East Atlantic Ocean", "Riiser Larsen Sea", "Med", "Nth", "Bas", "Bla", "Red Sea", "Cosmonauts Sea", "McH", "West Indian Ocean", "Arabian Sea", "North Indian Ocean", "South Indian Ocean", "East Indian Ocean", "Mawson Sea", "D'urville Sea", "Caspian Sea", "Amundsen Sea", "Tasman Sea", "Java Sea", "South China Sea", "Bay of Bengal", "Phillipine Sea", "East China Sea", "Sea of Japan", "Sea of Okhostk", "East Siberian Sea", "Arctic Ocean"]
an = 1901
campagnes = ["Campagne d'été ", "Campagne d'automne "]
n_campagne = 0

#Mes fonctions :
def formatage(path_file): 
    obfi = open(path_file, "r")
    while 1:
        line = obfi.readline()
        if line == '':
            break
        line = line.replace('\n', '')
        line = '"' + line + '"' + ","
        print(line, end='')    
def Pb():
    region_cible = regions[randint(0, len(regions)-1)]
    pbs = ["une epidemie ", "un volcan ", "une famine ", "un accident ", "un seisme "]
    pb = pbs[randint(0, len(pbs)-1)]

    retour = "Malus de defense : " + str(region_cible) + " subit " + str(pb) + "soit un malus de 0.5 en defense. " + "\n"
    return retour
def isolement():
    region_cible = regions[randint(0, len(regions)-1)]
    retour = "Isolement : " + str(region_cible) + " subit une tempete de neige ou de sable et rencontre donc un isolement complet du reste du monde, les troupes ne peuvent ni entrer ni sortir. " + "\n"
    return retour
def Rebellion():
    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
    retour = "Guerre Civile : " + str(region_cible) + " subit une guerre civile, la region s'autonomise et compte bien se defendre. Elle devient neutre et une armée blanche apparait. " + "\n"                           
    return retour  
def MerGelée():
    region_cible = mers[randint(0, len(mers)-1)]
    retour = "Mer Gelée : " + str(region_cible) + " est traversée par une vague de froid; la mer a gelé. Les unités terrestres pourront la traverser pour la prochaine campagne contrairement aux flottes. Si une flotte est prise par la glace, elle empeche la circulation dans cette mer et ne peut pas bouger lors de cette campagne. " + "\n"
    return retour
def SoutienPopulaire():           
    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
    retour = " Soutien Populaire : L'armée de " + str(region_cible) + " profite du soutien popupaire, qui lui procure 0.5 de bonus en attaque et lors de cette campagne. " + "\n"       
    return retour
def Blitzkrieg():
    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
    retour = "Blitzkrieg : un reservoir de super carburant est decouvert en " + str(region_cible) + ". L'unité presente sur cette case peut se deplacer 2 fois pour la prochaine campagne. " + "\n"                       
    return retour   
def enlisement():
    region_cible = regions_terrestre[randint(0, len(regions_terrestre)-1)]
    retour = "Enlisement : L'unité terreste de " + str(region_cible) + " n'a pas été assez prudente et s'est enlisée dans un marais. Elle ne pourra bouger lors de la campagne suivante que si une unité alliée se trouve sur une case adjacente. " + "\n"
    return retour
def date():
    année = int(an + n_campagne/2)
    if n_campagne - 2*int(n_campagne/2) == 0:
        campagne = campagnes[0]
    else:
        campagne = campagnes[1]
    retour = str(campagne) + str(année) + ": " + "\n"
    print(retour)
    return retour    
def LaTotale():
    global n_campagne
    retour, liste_actions = '', []
    for i in range(randint(2, 8)):
        dico_actions_possibles = {"1" : Pb(), "2" : isolement(), "3" : Rebellion(), "4" : MerGelée(), "5" : SoutienPopulaire(), "6" : Blitzkrieg(), "7" : enlisement()}
        print(i)
        liste_actions.append(dico_actions_possibles[str(randint(1,7))])
    for i  in liste_actions:
        if i != None:
            retour = retour + " --> " + str(i)
    
    n_campagne += 1 

    if retour =='':
        retour = "rien a signaler pour cette campagne."
    return retour

async def get_msg(channel: discord.TextChannel):
    return [message async for message in channel.history(limit=None)]

@client.event
async def on_ready():
    print("connected")
    
@client.event
async def on_message(message: discord.Message):
    print(message.content)
    
    if message.content == "events" and message.author.id in admin_liste:
            print(message.channel)
            msg = str(date()) + str(LaTotale()+ "\n .")
            await message.channel.send(msg)
            await message.delete()
            
    elif message.content == "eventss":
        await message.channel.send("La fin du monde a commmencée... Inutile de continuer la partie.  😡")
        await message.delete()
    
    elif message.content.startswith("clean ") and message.author.id in admin_liste:
        try:
            n = int(message.content.split("clean ")[-1])
        except:
            await message.reply("Entrez un entier")
            return
        messages = await get_msg(message.channel)
        for x in range(n):
            await messages[x].delete()
            
    elif message.content == "date" and message.author.id in admin_liste:
        await message.channel.send(date())
        await message.delete()
    
    elif message.content.startswith("change date ") and message.author.id in admin_liste:
        global n_campagne
        try:       
            n_campagne = int(message.content.split("change date ")[-1])
        except:
            await message.reply("Entrez un entier")
            return
                    
                    
client.run(TOKEN)
